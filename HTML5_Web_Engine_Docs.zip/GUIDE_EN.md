# HTML5 Web Engine — Complete Guide

---

## Table of Contents
1. Interface Overview
2. Elements
3. Element Properties
4. Styling
5. Logic (Behavior) System
6. Animations
7. Creating a Game
8. Creating a Website
9. Multi-page Navigation
10. Saving and Export
11. Keyboard Shortcuts
12. Tips & Troubleshooting

---

## 1. Interface Overview

The application consists of 4 parts:

```
┌──────────────────────────────────────────────┐
│                  TOP BAR                     │
├─────────────┬──────────────────┬─────────────┤
│    LEFT     │     CANVAS       │    RIGHT    │
│  (elements) │  (work area)     │  (settings) │
└─────────────┴──────────────────┴─────────────┘
```

**Top Bar** — main controls: mode switching, undo/redo, loop, play, save, export, and more.

**Left Panel** — element list, split into Web, Shape, and Game sections.

**Canvas** — the work area. Drag elements here and position them.

**Right Panel** — all settings for the selected element: properties, style, logic, animation, SEO.

---

## 2. Elements

### Web Elements
| Element | Purpose |
|---|---|
| Navbar | Site header / navigation bar |
| Hero | Large banner for the main section |
| Card | Content card block |
| Input | Text input field |
| Button | Clickable button |
| Image | Display an image |
| Video | Video player |
| Audio | Audio player |
| Trigger | Invisible zone for behaviors |

### Shapes
| Element | Purpose |
|---|---|
| Rectangle | Basic block or container |
| Text | Heading or paragraph |

### Game Elements
| Element | Purpose |
|---|---|
| Player | Player-controlled character |
| Enemy | Auto-moving obstacle |
| Platform | Surface the player can stand on |
| Coin | Collectible bonus (+10 score) |
| Bullet | Projectile |
| Wall | Impassable barrier |
| Trap | Damage zone |
| NPC | Non-player character |
| Item | Collectible item (+5 score) |
| Checkpoint | Save point — changes color on contact |
| HP Bar | Health bar |
| Score | Score display |

---

## 3. Element Properties (PROPERTIES tab)

After selecting an element, the right panel shows the **PROPERTIES** tab:

**Position & Size:**
- **X, Y** — position inside the canvas as a percentage (0–100)
- **Width, Height** — size in pixels

**Content:**
- **Name** — element identifier, used as the behavior target. Must be **unique**
- **Text** — text content inside the element
- **Href** — link URL for `<a>` tags
- **Src** — URL for image, video, or audio
- **Z-Index** — layer order (higher number = on top)
- **CSS Class** — additional CSS class added on export
- **HTML Tag** — which tag to use on export (`div`, `section`, `h1`, `p`, `button`, etc.)
- **Cursor** — enable pointer cursor (hand icon)
- **Lock** — lock the element to prevent accidental movement

---

## 4. Styling (STYLE tab)

**Colors:**
- Background — color picker or gradient text (`linear-gradient(135deg, #000, #111)`)
- Text color

**Border:**
- Color, width (px), type (solid / dashed / dotted)
- Radius — round the corners

**Typography:**
- Font — Orbitron, Exo 2, Share Tech Mono, Press Start 2P, Bungee, Georgia, Arial
- Size (px), weight, alignment

**Effects:**
- Shadow — format: `0 0 20px #00d4ff`
- Opacity — 0 (invisible) to 1 (fully visible)
- Blur, contrast, brightness filters

---

## 5. Logic System (LOGIC tab)

Each element can have one or more **trigger → action** chains.

### How to apply:
1. Select **TRIGGER** — when should it fire
2. Select **ACTION** — what should happen
3. Enter **TARGET / VALUE** — who or what value
4. Enter **CONDITION** (optional) — only fire when this is true
5. Press **✔ APPLY**

### Triggers:
| Trigger | When |
|---|---|
| click | On click |
| dblclick | On double click |
| mouseenter | When cursor enters |
| mouseleave | When cursor leaves |
| touchstart | On mobile tap |
| load | When the page loads |
| change | When value changes |

### Actions:
| Action | Target field |
|---|---|
| show | Element name |
| hide | Element name |
| toggle | Element name |
| setText | Element name |
| setBg | Element name |
| navigate | `https://...` URL (new tab) |
| navigateSame | `https://...` URL (same tab) |
| switchPage | Page number (`1`, `2`, `3`...) |
| startLoop | Leave empty |
| stopLoop | Leave empty |
| addScore | Number to add (`10`) |
| setHP | HP value (`0`–`100`) |
| setVar | `name=value` |
| addVar | `name+number` |
| customJS | — (write JavaScript code) |

### Writing conditions:
The **CONDITION** field below the target is optional. Examples:
```
score > 50
myVar === 'active'
lives > 0
```
If the condition is false, the action will not run.

### Multiple behaviors on one element:
Each trigger can be used once per element. Example on one button:
- `mouseenter` → `show` (another element)
- `mouseleave` → `hide` (same element)
- `click` → `navigate`

---

## 6. Animations (ANIM tab)

### CSS Animations:
| Name | Effect |
|---|---|
| Rotate | Continuous rotation |
| Scale | Grow and shrink |
| Move X | Slide left and right |
| Move Y | Slide up and down |
| Pulse | Fade in and out |
| Shake | Vibrate |
| Glow | Glowing light effect |
| Bounce | Bouncing |
| Spin 3D | 3D rotation on Y axis |
| Flip | Horizontal flip |
| Fade In | Appear from invisible |

### Settings:
- **Duration** — how long one cycle lasts (seconds)
- **Repeat** — how many times (1, 3, 5, or infinite)
- **Easing** — speed curve of the animation

### Transform:
- Rotation — in degrees (`45`, `90`, `180`)
- Scale X / Y — (`0.5` = half size, `2` = double size)

---

## 7. Creating a Game

### Platformer game:

**Step 1.** Drag these elements onto the canvas:
```
HP Bar    → x:2,  y:2  — top left
Score     → x:75, y:2  — top right
Player    → x:10, y:65
Platform  → x:0,  y:82 — wide ground
Platform  → x:55, y:55 — floating platform
Enemy     → x:60, y:70
Coin      → x:35, y:40
```

**Step 2.** Select Player → LOGIC tab:
```
Trigger : load
Action  : startLoop
```
Press **✔ APPLY**.

**Step 3.** Press **▷ PLAY** and use the keyboard to control.

**Controls:**
- `← →` or `A D` — move left / right
- `↑` or `W` or `Space` — jump

**What works automatically:**
- Enemy walks left and right, reverses at edges
- Coin disappears on contact, +10 score
- Item disappears on contact, +5 score
- Enemy contact reduces HP
- Trap contact reduces HP faster
- Checkpoint changes color on contact

### Top-down game:

Same setup, but Player moves in all four directions — `W A S D` or arrow keys. No gravity.

### Adding a start screen:

Create **Page 1** as the main menu with a Start button:
```
Trigger : click
Action  : switchPage
Target  : 2
```

On **Page 2** (the game), add to Player:
```
Trigger : load
Action  : startLoop
```

---

## 8. Creating a Website

### Simple landing page:

**1.** Navbar → x:0, y:0, full canvas width

**2.** Hero → x:0, y:8, full width — add a gradient background in STYLE

**3.** Cards → place several in a row

**4.** Button → inside or below the Hero

**5.** Button behavior:
```
Trigger : click
Action  : navigate
Target  : https://your-website.com
```

### Hover effect:

Select an element → LOGIC:
```
Trigger : mouseenter
Action  : setBg
Target  : element_name
```
Then add:
```
Trigger : mouseleave
Action  : setBg
Target  : element_name
```

---

## 9. Multi-page Navigation

### Sidebar (dashboard) layout:

Create **4 pages** using the + Page button at the bottom strip.

On each page add shared elements (header, sidebar menu).

Sidebar button behaviors:
```
Button 1 → switchPage → 1
Button 2 → switchPage → 2
Button 3 → switchPage → 3
```

**Important:** Enter the page **number**, not the page name.

### Bottom tab bar:

```
Card     → x:0,  y:88, w:100, h:12
Button 1 → x:5,  y:90, w:18,  h:8  → switchPage → 1
Button 2 → x:28, y:90, w:18,  h:8  → switchPage → 2
Button 3 → x:51, y:90, w:18,  h:8  → switchPage → 3
Button 4 → x:74, y:90, w:18,  h:8  → switchPage → 4
```

---

## 10. Saving and Export

### Save project (.json):
```
Top Bar → 💾 SAVE → DOWNLOAD .JSON
```
The JSON file is saved locally. To continue later, use **📂 LOAD** and paste the JSON content.

### Export the finished site (.html):
```
Top Bar → </> EXPORT → DOWNLOAD .HTML
```
This exports only the **render code** — no editor panels, clean HTML ready to use.

### Update the engine:
When a new version is released — click **⚡ HTML5 WEB ENGINE** in the top left, select the new `.html` file. Your project will be automatically restored.

---

## 11. Keyboard Shortcuts

| Key | Action |
|---|---|
| `Ctrl + Z` | Undo |
| `Ctrl + Y` | Redo |
| `Delete` | Delete selected element |
| `↑ ↓ ← →` | Move element 1px |
| `Escape` | Deselect |

---

## 12. Tips & Troubleshooting

**Elements overlapping** — Increase Z-Index. Higher number = on top.

**Element invisible** — Opacity may have been set to 0. Go to STYLE → Opacity → set to 1.

**Behavior not working** — Check the element name. The Target field must exactly match the element's **Name** field.

**Game loop not starting** — Make sure Player has a `load → startLoop` behavior applied.

**Element missing from export** — It may have gone outside the canvas boundaries. Check the X and Y percentage values.

**Too many elements causing lag** — Disable unnecessary animations (ANIM → ✕ None).

---

*HTML5 Web Engine — runs entirely in a single file. No internet connection or server required.*
