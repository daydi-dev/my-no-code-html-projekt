# HTML5 Web Engine — To'liq Qo'llanma

---

## Mundarija
1. Interfeys haqida
2. Elementlar
3. Element xossalari
4. Stil berish
5. Mantiq (Behavior) tizimi
6. Animatsiyalar
7. O'yin yaratish
8. Veb sayt yaratish
9. Ko'p sahifali navigatsiya
10. Saqlash va eksport
11. Keyboard shortcutlar
12. Maslahatlar va muammolar

---

## 1. Interfeys haqida

Ilova 4 qismdan iborat:

```
┌──────────────────────────────────────────────┐
│                  TOP BAR                     │
├─────────────┬──────────────────┬─────────────┤
│    CHAP     │     CANVAS       │    O'NG     │
│  (elementlar)│  (ish maydoni)  │ (sozlamalar)│
└─────────────┴──────────────────┴─────────────┘
```

**Top Bar** — asosiy tugmalar: rejim, bekor qilish, loop, play, saqlash, eksport va boshqalar.

**Chap panel** — elementlar ro'yxati. Web, Shakl va O'yin bo'limlariga ajratilgan.

**Canvas** — ish maydoni. Elementlarni shu yerga sudrab tashlanadi va joylashtiriladi.

**O'ng panel** — tanlangan elementning barcha sozlamalari: xossa, stil, mantiq, animatsiya, SEO.

---

## 2. Elementlar

### Web elementlar
| Element | Vazifasi |
|---|---|
| Navbar | Sayt sarlavha / navigatsiya paneli |
| Hero | Bosh qism uchun katta banner |
| Card | Kontent kartochkasi |
| Input | Matn kiritish maydoni |
| Tugma | Bosiladigan tugma |
| Rasm | Rasm ko'rsatish |
| Video | Video player |
| Audio | Audio player |
| Trigger | Ko'rinmas zona (behavior uchun) |

### Shakllar
| Element | Vazifasi |
|---|---|
| To'rtburchak | Oddiy blok yoki konteyner |
| Matn | Sarlavha yoki paragraf |

### O'yin elementlari
| Element | Vazifasi |
|---|---|
| Player | Boshqariladigan qahramon |
| Dushman | Avtomatik harakatlanadigan to'siq |
| Platform | Player turadigan sirt |
| Tanga | Yig'iladigan bonus (+10 ball) |
| O'q | Otiluvchi projectile |
| Devor | O'tib bo'lmaydigan to'siq |
| Tuzoq | Zarar beruvchi zona |
| NPC | Boshqarilmaydigan personaj |
| Narsa | Yig'iladigan predmet (+5 ball) |
| Nuqta | Checkpoint — teganda rang o'zgaradi |
| HP Bar | Sog'liq paneli |
| Ball | Hisob ko'rsatkichi |

---

## 3. Element xossalari (XOSSA tab)

Element tanlanganidan keyin o'ng panelda **XOSSA** tabida quyidagilar ko'rinadi:

**Joylashuv va o'lcham:**
- **X, Y** — canvas ichida foiz bilan joylashuv (0–100)
- **Kenglik, Balandlik** — piksel bilan o'lcham

**Kontent:**
- **Nomi** — element identifikatori. Behavior da nishon sifatida ishlatiladi. Har biri **unikal** bo'lishi shart
- **Matn** — element ichidagi matn
- **Href** — `<a>` tegi uchun havola manzili
- **Src** — rasm, video yoki audio URL manzili
- **Z-Index** — qatlamlar tartibi (katta raqam = ustida)
- **CSS Klass** — eksport da qo'shimcha CSS klass
- **HTML Teg** — eksport da qaysi teg ishlatilishi (`div`, `section`, `h1`, `p`, `button` va boshqalar)
- **Kursor** — pointer kursor (qo'l belgisi) yoqish
- **Qulflash** — elementni tasodifan siljib ketmasin deb mahkamlash

---

## 4. Stil berish (STIL tab)

**Ranglar:**
- Fon rangi — color picker yoki gradient matn (`linear-gradient(135deg, #000, #111)`)
- Matn rangi

**Chegara:**
- Rang, qalinlik (px), tur (solid / dashed / dotted)
- Radius — burchaklarni yumaloqlash

**Tipografiya:**
- Shrift — Orbitron, Exo 2, Share Tech Mono, Press Start 2P, Bungee, Georgia, Arial
- O'lcham (px), qalinlik, tekislash

**Effektlar:**
- Soya — `0 0 20px #00d4ff` formatida
- Shaffoflik — 0 (ko'rinmas) dan 1 (to'liq ko'rinadigan) gacha
- Xiralash, kontrast, yorqinlik filtrlari

---

## 5. Mantiq tizimi (MANTIQ tab)

Har bir elementga bir yoki bir nechta **trigger → harakat** zanjiri qo'shiladi.

### Qo'llash tartibi:
1. **TRIGGER** ni tanlang — qachon ishlasin
2. **HARAKAT** ni tanlang — nima qilsin
3. **NISHON / QIYMAT** ni kiriting — kimga yoki qanday qiymat
4. **SHART** kiriting (ixtiyoriy) — qanday holatda ishlasin
5. **✔ QOLLANISH** tugmasini bosing

### Triggerlar:
| Trigger | Qachon |
|---|---|
| click | Bosilganda |
| dblclick | 2 marta bosilganda |
| mouseenter | Kursor ustiga kelganda |
| mouseleave | Kursor ketganda |
| touchstart | Mobilda tegilganda |
| load | Sahifa ochilganda |
| change | Qiymat o'zgarganda |

### Harakatlar:
| Harakat | Nishon maydoni |
|---|---|
| show | Element nomi |
| hide | Element nomi |
| toggle | Element nomi |
| setText | Element nomi |
| setBg | Element nomi |
| navigate | `https://...` URL (yangi tab) |
| navigateSame | `https://...` URL (shu tab) |
| switchPage | Sahifa raqami (`1`, `2`, `3`...) |
| startLoop | Bo'sh qoldiring |
| stopLoop | Bo'sh qoldiring |
| addScore | Qo'shiladigan son (`10`) |
| setHP | HP qiymati (`0`–`100`) |
| setVar | `nomi=qiymat` |
| addVar | `nomi+son` |
| customJS | — (JavaScript kodi yoziladi) |

### Shart yozish:
**SHART** maydoni ixtiyoriy. Misollar:
```
score > 50
myVar === 'aktiv'
lives > 0
```
Shart bajarilmasa harakat ishlamaydi.

### Bir elementga bir nechta behavior:
Har bir trigger bir marta ishlatiladi. Misol — bitta tugmada:
- `mouseenter` → `show` (boshqa element)
- `mouseleave` → `hide` (o'sha element)
- `click` → `navigate`

---

## 6. Animatsiyalar (ANIM tab)

### CSS animatsiyalar:
| Nom | Effekt |
|---|---|
| Rotate | Aylanish |
| Scale | Kattalashib-kichrayish |
| Move X | Chapga-o'ngga siljish |
| Move Y | Yuqoriga-pastga siljish |
| Pulse | Miltillash |
| Shake | Silkinish |
| Glow | Yonish effekti |
| Bounce | Sakrash |
| Spin 3D | Y o'qi bo'ylab 3D aylanish |
| Flip | Gorizontal ag'darilish |
| Fade In | Ko'rinmas holatdan paydo bo'lish |

### Sozlamalar:
- **Davomiylik** — bir tsikl davom etish vaqti (soniya)
- **Takror** — necha marta (1, 3, 5 yoki cheksiz)
- **Easing** — animatsiya tezligi profili

### Transform:
- Burilish — gradus bilan (`45`, `90`, `180`)
- Masshtab X / Y — (`0.5` = yarm hajm, `2` = ikki barobar)

---

## 7. O'yin yaratish

### Platformer o'yin:

**1-qadam.** Canvas ga quyidagilarni tashlang:
```
HP Bar    → x:2,  y:2  — yuqori chap
Ball      → x:75, y:2  — yuqori o'ng
Player    → x:10, y:65
Platform  → x:0,  y:82 — keng, pastki zamin
Platform  → x:55, y:55 — havoda platform
Enemy     → x:60, y:70
Tanga     → x:35, y:40
```

**2-qadam.** Player ni tanlang → MANTIQ tab:
```
Trigger : load
Harakat : startLoop
```
**✔ QOLLANISH** ni bosing.

**3-qadam.** **▷ PLAY** bosing va klaviatura bilan boshqaring.

**Boshqaruv:**
- `← →` yoki `A D` — harakat
- `↑` yoki `W` yoki `Space` — sakrash

**Avtomatik ishlaydi:**
- Dushman chapdan o'ngga yuradi, chegara ga yetsa qaytadi
- Tanga tegilsa yo'qoladi, +10 ball
- Narsaga tegilsa yo'qoladi, +5 ball
- Dushman ga tegilsa HP kamayadi
- Tuzoqqa tegilsa HP tez kamayadi
- Checkpoint ga yetilsa rang o'zgaradi

### Top-down o'yin:

Xuddi yuqoridek, lekin Player to'rt tomonga harakatlanadi — `W A S D` yoki strelkalar. Tortishish kuchi yo'q.

### Bosh menyu qo'shish:

**1-sahifa** — bosh menyu, Start tugmasi bilan:
```
Trigger : click
Harakat : switchPage
Nishon  : 2
```

**2-sahifa** (o'yin) da Player ga:
```
Trigger : load
Harakat : startLoop
```

---

## 8. Veb sayt yaratish

### Oddiy landing page:

**1.** Navbar → x:0, y:0, canvas ning to'liq kengligi

**2.** Hero → x:0, y:8, to'liq kenglik — STIL da gradient fon bering

**3.** Bir nechta Card → bir qatorda joylashtiring

**4.** Tugma → Hero ichida yoki pastida

**5.** Tugmaga behavior:
```
Trigger : click
Harakat : navigate
Nishon  : https://sizning-saytingiz.com
```

### Hover effekti:

Elementni tanlang → MANTIQ:
```
Trigger : mouseenter
Harakat : setBg
Nishon  : element_nomi
```
Keyin qo'shing:
```
Trigger : mouseleave
Harakat : setBg
Nishon  : element_nomi
```

---

## 9. Ko'p sahifali navigatsiya

### Sidebar (kabinet) tizimi:

Pastdagi + Sahifa tugmasi bilan **4 ta sahifa** yarating.

Har bir sahifaga umumiy elementlar qo'ying (header, yon menyu).

Menyu tugmalariga behavior:
```
1-tugma → switchPage → 1
2-tugma → switchPage → 2
3-tugma → switchPage → 3
```

**Muhim:** Nishon maydoniga sahifa **nomini emas**, **raqamini** yozing.

### Pastki tab-bar:

```
Card     → x:0,  y:88, w:100, h:12
Tugma 1  → x:5,  y:90, w:18,  h:8  → switchPage → 1
Tugma 2  → x:28, y:90, w:18,  h:8  → switchPage → 2
Tugma 3  → x:51, y:90, w:18,  h:8  → switchPage → 3
Tugma 4  → x:74, y:90, w:18,  h:8  → switchPage → 4
```

---

## 10. Saqlash va Eksport

### Loyihani saqlash (.json):
```
Top Bar → 💾 SAQLASH → YUKLAB OLISH .JSON
```
JSON fayl kompyuterga tushadi. Keyinroq davom etish uchun **📂 YUKLASH** ni bosib JSON matnini joylashtiring.

### Tayyor saytni eksport qilish (.html):
```
Top Bar → </> EXPORT → YUKLAB OLISH .HTML
```
Faqat **render kodi** eksport qilinadi — editor panellari yo'q, ishlatishga tayyor toza HTML.

### Engine yangilash:
Yangi versiya chiqsa — yuqori chap da **⚡ HTML5 WEB ENGINE** yozuviga bosing, yangi `.html` faylni tanlang. Loyiha avtomatik tiklanadi.

---

## 11. Keyboard Shortcutlar

| Tugma | Vazifasi |
|---|---|
| `Ctrl + Z` | Bekor qilish |
| `Ctrl + Y` | Qaytarish |
| `Delete` | Tanlangan elementni o'chirish |
| `↑ ↓ ← →` | Elementni 1px siljitish |
| `Escape` | Tanlovni bekor qilish |

---

## 12. Maslahatlar va muammolar

**Elementlar bir-birining ustiga chiqib ketsa** — Z-Index ni oshiring. Katta raqam = ustida.

**Element ko'rinmay qolsa** — Shaffoflik 0 ga tushib qolgan bo'lishi mumkin. STIL → Shaffoflik → 1 qiling.

**Behavior ishlamayapti** — Element nomini tekshiring. Nishon maydoni va elementning **Nomi** maydoni aynan bir xil bo'lishi kerak.

**O'yin loop ishlamayapti** — Player ga `load → startLoop` behavior qo'shilganligini tekshiring.

**Eksport da element chiqmayapti** — Element canvas chegarasidan tashqariga chiqib ketgan bo'lishi mumkin. X va Y foiz qiymatlarini tekshiring.

**Ko'p element sekinlashtiryapti** — Keraksiz animatsiyalarni o'chiring (ANIM → ✕ Yo'q).

---

*HTML5 Web Engine — bitta faylda to'liq ishlaydi. Internet yoki server talab qilmaydi.*
